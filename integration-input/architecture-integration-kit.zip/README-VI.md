# ORBITA — Architecture rework integration (2 ZIP → standalone latest)

**Mục đích:** áp thiết kế Beacon, Cinema, Central Information Station từ `reconstruct-sci-fi-3d-architecture (1).zip` và **chỉ FOH** từ `orbita-four-exhibits-arena-preview-fix.zip` lên checkout **mới nhất** của `Khanh-glitch/Kh-nh-port`, tránh copy đè trọn vẹn source hoặc entrypoint cũ.

**Mốc HEAD đã đối chiếu trên GitHub:** `arena/1e2ad83c-kh-nh-port` @ `0f8b43961340a7e00cbd77c97e13145a1fefa92c` (14/11/2026, 05:27 UTC). Nếu agent thấy HEAD mới hơn, dùng HEAD mới, kiểm tra các điểm nối và chạy dry-run trước; không checkout ngược thời gian.

## Các thay đổi được phép

| Công trình | Nguồn | Tệp / cách tích hợp |
|---|---|---|
| Beacon | ZIP `(1)` | `scene/Beacon.tsx`, `scene/beacon/parts.ts` — giữ `SocialDrops` và toàn bộ URL từ runtime hiện có |
| Mini Cinema | ZIP `(1)` | `scene/cinema/Architecture.tsx` — **thay duy nhất khối geometry JSX** trong `scene/Cinema.tsx`. Giữ danh sách phim, tách MP4, audio/video texture, Dream/Drive/YouTube, trailer/teaser, `CinemaVideo`, mọi Hit điều khiển, ánh sáng động từ video. Màn hình vẫn 8.3 × 3.64 m và vẫn là `screenTex.tex` hiện tại |
| Central Station | ZIP `(1)` | `scene/Station.tsx` + đồ họa, kiosk, mô hình bản đồ ở tâm `0,0`; **dời Orb sang `(-47,-3)`** qua `layout.ts`. Atlas giữ đầy đủ logic điều hướng. Phần số liệu giả từ `PANELS` của phôi được loại khỏi những bề mặt mới; không sửa dữ liệu gốc hay các link |
| FOH | ZIP `orbita-four-exhibits-arena-preview-fix.zip` | `scene/FohStation.tsx`, `scene/arch/geomBuilder.ts`, `scene/arch/materials.ts`. **Chỉ đổi bàn FOH và callback nối vào Stage đang có**, không thay cảnh sân khấu/ShowSystem |
| Vật liệu chung | ZIP `(1)` | `scene/kit/geo.ts`, `scene/kit/materials.ts` |

**Các tệp tuyệt đối giữ bản checkout mới nhất:** `source/src/App.tsx`, `source/src/scene/Experience.tsx`, `source/src/reality/RealityHost.tsx`, `source/src/reality/music.ts`, `source/src/stage/ShowSystem.tsx`, `source/src/stage/shows.ts`, `source/src/ui/Overlay.tsx`, `source/src/scene/ShowcaseWarmup.tsx`, `source/src/perfLadder.ts`, dữ liệu media/URL, `source/public`, assets/immersive, scripts HX-9. Không đưa `src/preview/ExhibitTour.tsx` hoặc preview `App.tsx` vào runtime.

**Tối ưu không hạ chất lượng:** hình học phức tạp đã được gộp/instanced trong asset nguồn; không giảm shadow, resolution, DPR hay video bitrate; không can thiệp existing quality tiers. FOH vẫn giữ ba màn **512×420** cập nhật tối đa **18Hz khi camera hướng vào FOH**, nhưng chỉ upload đúng phần 512×420 từng màn thay vì upload cả atlas 1536×420 ba lần. Không thay đổi số pixel nhìn thấy trên màn FOH. Đây là tối ưu được kiểm chứng tĩnh, chưa đo GPU.

## Áp vào commit mới nhất

> Có thể giao chính ZIP này cho Arena, yêu cầu agent dùng nó trên **latest checkout** của repo, không copy nguyên cả hai ZIP. Cần có Python 3, Node/npm và cài dependency của **repo**, không dùng preview độc lập từ ZIP kia.

1. Trong Arena, checkout nhánh làm việc riêng **từ HEAD mới nhất** của `arena/1e2ad83c-kh-nh-port`. Không push/merge trực tiếp vào `main` hoặc nhánh HX-9 đang làm.
2. Giải nén bộ kit này vào thư mục ngoài repo (ví dụ `../architecture-integration-kit`).
3. Từ thư mục repo:

```bash
python3 ../architecture-integration-kit/integrate_latest.py . --dry-run
python3 ../architecture-integration-kit/integrate_latest.py .
cd source && npm ci && npx tsc --noEmit && cd ..
node ../architecture-integration-kit/verify_source.mjs .
node ../architecture-integration-kit/sync_architecture_standalone.mjs . --dry-run
node ../architecture-integration-kit/sync_architecture_standalone.mjs .
node scripts/build-pages.mjs
```

`integrate_latest.py` **thất bại chủ động** nếu source khác với các neo đã kiểm tra, xung đột tệp kiến trúc đã tồn tại, hoặc module bảo vệ nằm trong mutation plan. Nó tạo `.architecture-backup/` cho các tệp nguồn cũ và `ARCHITECTURE_INTEGRATION_REPORT.json` với danh sách chỉnh + SHA-256 của core được bảo vệ.

`sync_architecture_standalone.mjs` **không ghi lại App**, chỉ cập nhật **14 module liên quan kiến trúc** bên trong import-map của **root `index.html` đang chạy thật** (bao gồm các module mới). Nó tạo `index.before-architecture-integration.html` để rollback, so sánh hash của 7 module core sau khi đồng bộ và không dựng lại spaceship. Sau đó `build-pages.mjs` sẽ xuất đúng `dist-pages` với video/ảnh/assets hiện có.

**LƯU Ý:** chạy `npm run build` riêng trong `source` **KHÔNG** cập nhật root runtime standalone. Phải chạy bước sync ở trên, đừng lấy root HTML từ hai ZIP.

## Acceptance trước khi có quyền merge/release

1. Test first-paint HX-9 → island đúng thứ tự; không đen màn, không loading loop, không tự động nhảy vào preview tour.
2. Nhìn 3D thật: Station ở tâm, Orb đã dời, Beacon full geometry & 6 link, Cinema đủ ngoại thất/nội thất, FOH giàu chi tiết. Ảnh trước–sau cùng camera, 1920×1080/1366×768/mobile.
3. Cinema: tất cả **6 video** đổi được; local split MP4 và nút mở Drive/URL đúng; sound, pointer lock, screen texture, màu ánh sáng và cửa tự động còn hoạt động; không thêm video player chồng lên.
4. Stage: 3 chương trình; `ShowSelector`, FOH cue/pad, Play/Stop, Pyro, LED video, focus viewer, ảnh và panel nổi, preload/show timing vẫn hoạt động.
5. Beacon: icon rơi, mỗi icon đi tới đúng external URL hiện tại, không thay `layout.ts` PROFILES/links.
6. Piano/UEH và Colossus/Ragnarok/Products/Rubik/VNG: hồi quy không khác, đặc biệt shader compile, warm-up GPU, media; kiểm tra E gần Station không mở `panel=station` giả.
7. So sánh cold load + first island paint + median/p95 frame time + WebGL draw calls/triangles/textures trên cùng phần cứng, cùng quality tier. Không đạt thì tối ưu culling, merging, update schedule — **không** giảm resolution, xóa hiệu ứng hay khóa High để đạt FPS.
8. `index.html` sau sync phải là file dùng để build `dist-pages`; kiểm tra URL thật, không chỉ `npm run build` hay screenshot của một trang preview.

**Trạng thái bàn giao:** đã xác minh source/provenance, thử dry-run, chạy static TSX/relative-import gate trên bộ nguồn thử, và thử đồng bộ import-map trên một HTML fixture. **Chưa chạy browser/WebGL của commit GitHub mới nhất; chưa commit/push, chưa deploy.** Bản này là bộ chỉnh sửa có thể áp dụng ngay trong checkout latest và được thiết kế để fail-closed nếu repo phát sinh thay đổi ngoài dự kiến.

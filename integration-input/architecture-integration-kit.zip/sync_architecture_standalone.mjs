/** Surgical update of the ORIGINAL integrated root/index.html import map.
 * Only architecture modules listed below are republished. No new Vite app entry,
 * no spaceship rebundle, no video transcode, no quality gate changes.
 * Run AFTER integrate_latest.py, from any working dir:
 *   node sync_architecture_standalone.mjs /path/to/Kh-nh-port --dry-run
 *   node sync_architecture_standalone.mjs /path/to/Kh-nh-port
 */
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { resolve, relative, dirname, join } from 'node:path'
const require=createRequire(import.meta.url)
const root=resolve(process.argv[2]||'.')
const dry=process.argv.includes('--dry-run')
const src=join(root,'source','src')
const htmlPath=join(root,'index.html')
if(!existsSync(htmlPath)||!existsSync(join(src,'scene','Station.tsx')))throw Error('Need actual integrated repo root + new Station source. Do not point at the preview ZIP.')
const ts=require(join(root,'source','node_modules','typescript'))
const old=readFileSync(htmlPath,'utf8')
const tag='<script id="orbita-embedded-map" type="application/json">'
const x=old.indexOf(tag),begin=x+tag.length,end=old.indexOf('</script>',begin)
if(x<0||end<0)throw Error('Refusing to overwrite root HTML with missing original embedded module map')
const map=JSON.parse(old.slice(begin,end))
if(!map['orbita/main']||!map['orbita/App']||!map['orbita/reality/RealityHost'])throw Error('Original standalone lacks required core modules')
const immutable={}
for(const key of ['orbita/main','orbita/App','orbita/reality/RealityHost','orbita/reality/music','orbita/stage/ShowSystem','orbita/stage/shows','orbita/ui/Overlay']){
 if(!(key in map))throw Error('Missing protected module '+key)
 immutable[key]=createHash('sha256').update(map[key]).digest('hex')
}
const modules=[
 'layout',
 'scene/Exhibits',
 'scene/Player',
 'scene/Stage',
 'scene/FohStation',
 'scene/arch/geomBuilder',
 'scene/arch/materials',
 'scene/Beacon',
 'scene/beacon/parts',
 'scene/Cinema',
 'scene/cinema/Architecture',
 'scene/Station',
 'scene/kit/geo',
 'scene/kit/materials',
]
for(const f of modules)map['orbita/'+f]='pending' // register all import slots FIRST
function sourceFile(f){
 for(const ext of ['.tsx','.ts']){
  const full=join(src,f+ext);if(existsSync(full))return full
 }
 throw Error('Missing source: '+f)
}
const stats=[]
for(const f of modules){
 const fullname=sourceFile(f)
 const raw=readFileSync(fullname,'utf8')
 const tx=ts.transpileModule(raw,{fileName:fullname,reportDiagnostics:true,compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,removeComments:false}})
 const errors=(tx.diagnostics||[]).filter(x=>x.category===ts.DiagnosticCategory.Error)
 if(errors.length)throw Error(f+': '+errors.map(e=>ts.flattenDiagnosticMessageText(e.messageText,' ')).join('\n'))
 let js=tx.outputText.replace(/(\bfrom\s*['"])(\.{1,2}\/[^'"]+)(['"])/g,(_all,pre,spec,post)=>{
  const rel=relative(src,resolve(dirname(fullname),spec)).replace(/\\/g,'/').replace(/\.(tsx?|jsx?)$/,'')
  const id='orbita/'+rel
  if(rel.startsWith('..')||!(id in map))throw Error(`Cannot embed ${f}: imported ${id} is absent`)
  return pre+id+post
 })
 const id='orbita/'+f
 map[id]='data:text/javascript;base64,'+Buffer.from(js).toString('base64')
 stats.push({module:id,bytes:js.length})
}
for(const [key,hash] of Object.entries(immutable)){
 const now=createHash('sha256').update(map[key]).digest('hex')
 if(hash!==now)throw Error('Protected runtime module changed: '+key)
}
const next=old.slice(0,begin)+JSON.stringify(map)+old.slice(end)
if(!next.includes('orbita-embedded-map')||!next.includes('orbita/main'))throw Error('Root standalone lost bootstrap')
if(!dry){
 const backup=join(root,'index.before-architecture-integration.html')
 if(existsSync(backup))throw Error('Backup already exists: '+backup+'; refuse to overwrite')
 writeFileSync(backup,old)
 writeFileSync(htmlPath,next)
}
console.log(JSON.stringify({status:dry?'DRY_RUN_READY':'SOURCE_AND_ROOT_SYNCED',modulesUpdated:modules.length,oldHtmlBytes:Buffer.byteLength(old),newHtmlBytes:Buffer.byteLength(next),protectedModules:Object.keys(immutable),updated:stats,visualRuntimeQA:'NOT_DONE'},null,2))

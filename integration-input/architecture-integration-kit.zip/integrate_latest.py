#!/usr/bin/env python3
"""Surgical 3D-only integration of two user-supplied arena ZIPs into a checked out ORBITA repo.
No changes to App, RealityHost, ShowSystem, media/link data, Vite config, or deployment root index.
Usage: python3 integrate_latest.py /path/to/Kh-nh-port [--dry-run]
"""
from __future__ import annotations
import argparse, hashlib, json, shutil, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OVERLAY = HERE / 'overlay'
STAGE_START = '      {/* bàn FOH */}'
STAGE_END = '      <Hit id="stage-body"'
CINEMA_START = '      {/* sàn, tường, mái */}'
CINEMA_END = '      <pointLight position={[0, 4.2, 0]}'


def once(text: str, old: str, new: str, context: str) -> str:
    n = text.count(old)
    if n != 1:
        raise ValueError(f'{context}: expected 1 exact anchor, got {n}: {old[:125]!r}')
    return text.replace(old, new, 1)


def section(text: str, a: str, b: str, replacement: str, ctx: str) -> str:
    x = text.find(a)
    y = text.find(b, x + len(a)) if x >= 0 else -1
    if x < 0 or y <= x:
        raise ValueError(f'{ctx}: missing architecture section anchors ({a[:44]!r}, {b[:44]!r})')
    if text.count(a) != 1:
        raise ValueError(f'{ctx}: ambiguous section start')
    return text[:x] + replacement + text[y:]


def insert_after_imports(s: str, statement: str) -> str:
    if statement in s: return s
    ends = [line for line in s.splitlines() if line.startswith('import ')]
    if not ends: raise ValueError('No import declarations')
    return once(s, ends[-1]+'\n', ends[-1]+'\n'+statement+'\n', 'module import')


def patch_layout(s: str) -> str:
    if "  | 'station'" not in s:
        s = once(s,"  | 'orb'\n", "  | 'orb'\n  | 'station'\n", 'layout ExhibitId')
    if '  station: {' not in s:
        x = "  orb: { id: 'orb', name: 'Singularity Orb', x: 0, z: 0, rotY: 0, color: '#b66bff' },"
        # Always preserve other layout definitions and exact URLs below the map.
        y = "  station: { id: 'station', name: 'Central Information Station', x: 0, z: 0, rotY: 0, color: '#7fdcff' },\n  orb: { id: 'orb', name: 'Singularity Orb', x: -47, z: -3, rotY: 0.5, color: '#b66bff' },"
        if x in s: s = once(s,x,y,'layout station/orb')
        else: raise ValueError('Layout orb coordinates changed: inspect relocation before integrating')
    else:
        if "x: -47, z: -3" not in s: raise ValueError('Station exists but Orb location is not intended; avoid destructive overwrite')
    return s


def patch_exhibits(s: str) -> str:
    if "import { Station } from './Station'" not in s:
        s=insert_after_imports(s,"import { Station } from './Station'")
    if '<Station />' not in s:
        s=once(s,'    <group>\n','    <group>\n      <Station />\n','Exhibits placement')
    return s


def patch_stage(s: str) -> str:
    if "from './FohStation'" not in s:
        if "import { FohStation } from './Foh'" in s:
            s = s.replace("import { FohStation } from './Foh'", "import { FohStation } from './FohStation'")
        else:s=insert_after_imports(s,"import { FohStation } from './FohStation'")
    if 'kick: 0.2' not in s:
        s=once(s,"scene: 0, beatOn: false, lastDraw:","scene: 0, beatOn: false, kick: 0.2, lastDraw:",'FOH live kick state')
    if 'st.kick = kick' not in s:
        s=once(s,'    const energy = st.beatOn ? 1 : 0.45', '    st.kick = kick\n    const energy = st.beatOn ? 1 : 0.45','FOH audio telemetry')
    # Latest deployed branch renders a legacy flat console. Strip ONLY that JSX.
    if STAGE_START in s:
        foh='''      {/* FOH architecture only; media/show/video/event state remains owned by Stage + ShowSystem. */}
      <FohStation
        scenes={SCENES}
        liveState={st}
        onSelectScene={setScene}
        onToggleBeat={toggleBeat}
        onFire={fire}
      />
'''
        s=section(s,STAGE_START,STAGE_END,foh,'Stage old console')
    elif '<FohStation' in s:
        # Supports applying over a development build that already uses an older FOH component.
        a=s.index('      <FohStation')
        b=s.index('/>',a)+2
        s=s[:a]+'''      <FohStation scenes={SCENES} liveState={st} onSelectScene={setScene} onToggleBeat={toggleBeat} onFire={fire} />'''+s[b:]
    else:raise ValueError('Stage FOH signature unknown, refuse to rewrite show structure')
    # Remove only obsolete per-frame controllers of the deleted flat console.
    if '    platters.current.forEach((p, i) => {' in s:
        s=section(s,'    platters.current.forEach((p, i) => {','    // hạt',
                  '    // Physical faders, cue pads & deck feedback now update in FohStation.\n\n','Stage legacy controls')
    # Drop obsolete, now unused useMemo/material/ref allocations; keep st.press and onCue semantics.
    obsolete=[
       '  const padMats = useMemo(() => SCENES.map((s) => new THREE.MeshBasicMaterial({ color: new THREE.Color(s.colors[0]), toneMapped: false })), [])\n',
       "  const playMat = useMemo(() => new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff3b3b'), toneMapped: false }), [])\n",
       "  const boomMat = useMemo(() => new THREE.MeshBasicMaterial({ color: new THREE.Color('#ffd23d'), toneMapped: false }), [])\n",
       '  const padGroups = useRef<(THREE.Group | null)[]>([])\n',
       '  const platters = useRef<(THREE.Mesh | null)[]>([])\n',
       '  const padX = [-1.05, -0.35, 0.35, 1.05]\n',
    ]
    for old in obsolete:s=s.replace(old,'')
    # Collision at original desk is enlarged marginally to agree with wings.
    s=s.replace("    { type: 'box', x: 0, z: 12, hw: 3.3, hd: 1.0 },",
                "    { type: 'box', x: 0, z: 12.05, hw: 3.35, hd: 0.92 },\n    { type: 'circle', x: -3.55, z: 13.38, r: 0.42 },\n    { type: 'circle', x: 3.55, z: 13.38, r: 0.42 },")
    for must in ['<FocusViewer />','<LedVideo stageGroup={root} />','<InfoVeil', '<PhotoWings','<ShowSelector','<ShowFX','<ShowPreloader', 'onToggleBeat={toggleBeat}', 'onSelectScene={setScene}']:
        if must not in s:raise ValueError(f'Stage critical integration missing after patch: {must}')
    return s


def patch_cinema(s: str, arch_cinema: str) -> str:
    s=insert_after_imports(s,"import { CinemaArchitecture } from './cinema/Architecture'")
    s=s.replace('const leftDoor = useRef<THREE.Mesh>(null)','const leftDoor = useRef<THREE.Group>(null)')
    s=s.replace('const rightDoor = useRef<THREE.Mesh>(null)','const rightDoor = useRef<THREE.Group>(null)')
    # Match geometry-accurate collision to the new walls/seats (ONLY collider array).
    start='  useWorldColliders(ex, ['
    old_end='\n  ])'
    if start in s and start in arch_cinema:
        a=arch_cinema.index(start)
        b=arch_cinema.index(old_end,a)+len(old_end)
        intended=arch_cinema[a:b]
        x=s.index(start)
        y=s.index(old_end,x)+len(old_end)
        s=s[:x]+intended+s[y:]
    if CINEMA_START in s:
        replacement='''      {/* Geometry-only import from architecture (1): keep existing video components & event handlers. */}
      <CinemaArchitecture
        inside={inside}
        filmActive={projectFilm !== null}
        leftDoor={leftDoor}
        rightDoor={rightDoor}
        bulbs={bulbs}
        bulbCount={bulbPos.length}
        marquee={marquee}
        posters={posters}
        teaser={<CinemaTeaser />}
        screenTex={screenTex.tex}
        beamGeo={beamGeo}
        beamMat={beamMat}
      />
'''
        s=section(s,CINEMA_START,CINEMA_END,replacement,'Cinema room geometry')
    elif '<CinemaArchitecture' not in s:raise ValueError('Cinema existing geometry markers changed; preserve media and stop')
    for must in ['<LocalCinemaFilm', '<CinemaVideo', '<Hit id="cinema-screen"', '<Hit id="cinema-project-link"', '<Hit id="cinema-sign"','PROJECT_FILMS', 'attachSplitFilm', 'screenTex.tex.needsUpdate']:
        if must not in s:raise ValueError(f'Cinema must preserve runtime media interface: {must}')
    return s


def validate_no_injected_preview(root: Path):
    bad=['src/preview/ExhibitTour.tsx','src/preview/PreviewErrorBoundary.tsx']
    if any((OVERLAY / x).exists() for x in bad):raise ValueError('Preview modules in production overlay')


def write_with_backup(dest: Path, content: bytes, backup: Path, dry: bool):
    if dest.exists() and dest.read_bytes()==content:return False
    if not dry:
        if dest.exists():
            target=backup / dest.relative_to(backup.parent.parent) if False else backup / dest.name
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(dest,target)
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(content)
    return True


def main():
    a=argparse.ArgumentParser()
    a.add_argument('repo',type=Path,help='checked-out repository root or source directory')
    a.add_argument('--dry-run',action='store_true')
    args=a.parse_args()
    repo=args.repo.resolve()
    src=repo/'source' if (repo/'source'/'src'/'layout.ts').exists() else repo
    if not (src/'src'/'layout.ts').exists() or not (src/'src'/'scene'/'Stage.tsx').exists():
        raise SystemExit('Not an ORBITA repository checkout/source root')
    if not (src/'src'/'scene'/'Cinema.tsx').exists():raise SystemExit('Cinema module missing')
    validate_no_injected_preview(src)
    # All edits are planned and guarded in memory BEFORE any file is touched.
    edits={}
    for name,fn in [('layout.ts',patch_layout),('scene/Exhibits.tsx',patch_exhibits),('scene/Stage.tsx',patch_stage)]:
        dest=src/'src'/name;edits[dest]=fn(dest.read_text()).encode()
    arch_cinema=(HERE/'architecture_reference'/'Cinema.tsx').read_text()
    dest=src/'src'/'scene'/'Cinema.tsx'
    original_cinema=dest.read_text()
    edited_cinema=patch_cinema(original_cinema,arch_cinema)
    # The file's media definitions and playback logic before the Cinema component must stay byte-identical.
    prefix=lambda s:s.split('export function Cinema()',1)[0]
    o=prefix(original_cinema)
    n=prefix(edited_cinema)
    if "import { CinemaArchitecture } from './cinema/Architecture'" not in prefix(original_cinema):
        n=n.replace("import { CinemaArchitecture } from './cinema/Architecture'\n",'')
    if o!=n:raise ValueError('Cinema playback definitions changed; integration cancelled')
    # Remove ONLY dead legacy render materials from the old cinema structure.
    # These are not the film surfaces; new architecture keeps the original screenTex.
    for line in [
        "const velvet = new THREE.MeshStandardMaterial({ color: '#8c1226', roughness: 0.92, metalness: 0 })\n",
        "const neonRed = new THREE.MeshBasicMaterial({ color: new THREE.Color('#ff3b3b').multiplyScalar(2.8), toneMapped: false })\n",
        "const warm = new THREE.MeshBasicMaterial({ color: new THREE.Color('#ffb070').multiplyScalar(2.2), toneMapped: false })\n",
    ]:
        if edited_cinema.count(line)==1:edited_cinema=edited_cinema.replace(line,'',1)
    if 'rbox(' not in edited_cinema and ' rbox,' in edited_cinema:
        edited_cinema=edited_cinema.replace('canvasTex, rbox, roundRect','canvasTex, roundRect')
    if 'mats.' not in edited_cinema:
        edited_cinema=edited_cinema.replace('PadRing, isFacing, mats, useWorldColliders','PadRing, isFacing, useWorldColliders')
    edits[dest]=edited_cinema.encode()
    # E-key fallback picks nearest EXHIBIT_LIST entry. New station ID must
    # route to existing 'about' panel (there is deliberately no fake 'station' panel).
    dest=src/'src'/'scene'/'Player.tsx'
    player_src=dest.read_text()
    if "best === 'station' ? 'about' : best" not in player_src:
        player_src=once(player_src,'if (best) openPanel(best as PanelId)',
            "if (best) openPanel((best === 'station' ? 'about' : best) as PanelId)",'Player E fallback')
    edits[dest]=player_src.encode()
    for p in OVERLAY.rglob('*'):
        if p.is_file():
            dest=src/p.relative_to(OVERLAY)
            if dest.exists() and dest.read_bytes()!=p.read_bytes() and 'Station.tsx' not in str(dest):
                raise ValueError(f'Architecture overlay conflicts with existing file, please inspect: {dest}')
            edits[dest]=p.read_bytes()
    # Safety fence: do not mutate release root, media, links, render quality, launch gate.
    protected=['src/App.tsx','src/scene/Experience.tsx','src/reality/RealityHost.tsx',
               'src/reality/music.ts','src/stage/ShowSystem.tsx','src/stage/shows.ts',
               'src/ui/Overlay.tsx','src/scene/ShowcaseWarmup.tsx','src/perfLadder.ts']
    for p in protected:
        if src/p in edits:raise ValueError(f'Protected file in mutation plan: {p}')
    protected_hashes = {p: hashlib.sha256((src/p).read_bytes()).hexdigest()
        for p in protected if (src/p).exists()}

    changed=[(p,data) for p,data in edits.items() if not p.exists() or p.read_bytes()!=data]
    try:
        version=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,stderr=subprocess.DEVNULL,text=True).strip()
    except Exception:version='UNVERIFIED(no git checkout)'
    print(f'Base HEAD: {version}')
    print('Mode:', 'DRY RUN' if args.dry_run else 'WRITE')
    for p,data in changed:print('  '+p.relative_to(src).as_posix(),len(data),'bytes')
    if not args.dry_run:
        backup=repo/'.architecture-backup'
        if changed and backup.exists():raise ValueError('Backup folder already exists; inspect previous integration first')
        for p,data in changed:
            if p.exists():
                dest=backup/p.relative_to(src)
                dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(p,dest)
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        (repo/'ARCHITECTURE_INTEGRATION_REPORT.json').write_text(json.dumps({
            'base_head':version,'source':'architecture (1) / FOH from four-exhibits ZIP',
            'changed':[p.relative_to(src).as_posix() for p,_ in changed],
            'protected_sha256':protected_hashes,'deployment_artifact_changed':False,'runtime_visual_qa':'NOT_DONE',
            'files_provenance':'MANIFEST.json'
        },ensure_ascii=False,indent=2))
    print(f'Planned: {len(edits)}; changed: {len(changed)}. Launch/media/core unchanged.')
    if not args.dry_run:print('IMPORTANT: source edited; standalone root index.html NOT regenerated. Build and render-QA before deploy.')

if __name__=='__main__':
    try:main()
    except Exception as e:print('INTEGRATION BLOCKED:',e,file=sys.stderr);sys.exit(2)

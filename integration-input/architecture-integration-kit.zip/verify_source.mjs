/** Static integration gates; use after applying integrate_latest.py.
 * This does not replace production build or browser-based WebGL validation.
 */
import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
const require = createRequire(import.meta.url)
const root = path.resolve(process.argv[2] || '.')
const src = fs.existsSync(path.join(root,'source','src','layout.ts')) ? path.join(root,'source') : root
let ts
try { ts = require(path.join(src,'node_modules','typescript')) } catch { console.error('Run npm ci in source/ to install TypeScript before verify_source.mjs'); process.exit(2) }
const read = f=>fs.readFileSync(path.join(src,'src',f),'utf8')
const stage=read('scene/Stage.tsx'), cinema=read('scene/Cinema.tsx'), layout=read('layout.ts'), exhibits=read('scene/Exhibits.tsx'),player=read('scene/Player.tsx')
const foh=read('scene/FohStation.tsx'), beac=read('scene/Beacon.tsx'),station=read('scene/Station.tsx')
const exists=f=>assert(fs.existsSync(path.join(src,'src',f)),`Missing ${f}`)
for(const file of ['scene/Station.tsx','scene/Beacon.tsx','scene/beacon/parts.ts','scene/cinema/Architecture.tsx','scene/kit/geo.ts','scene/kit/materials.ts','scene/FohStation.tsx','scene/arch/geomBuilder.ts','scene/arch/materials.ts'])exists(file)
assert(layout.includes("station: { id: 'station'"),'Central station absent from real EXHIBITS layout')
assert(layout.includes("orb: { id: 'orb', name: 'Singularity Orb', x: -47"),'Orb relocation absent')
assert(exhibits.includes('<Station />') && exhibits.includes('<Beacon />') && exhibits.includes('<Cinema />'),'Architecture exhibit not mounted')
assert(stage.includes('<FohStation') && !stage.includes('{/* bàn FOH */}'),'Old FOH still mounted')
for(const component of ['<ShowSelector','<InfoVeil','<PhotoWings','<LedVideo','<ShowFX','<ShowPreloader'])assert(stage.includes(component),`Stage lost existing ${component}`)
for(const tag of ['<LocalCinemaFilm','<CinemaVideo','<CinemaArchitecture','<Hit id="cinema-screen"','<Hit id="cinema-sign"','<Hit id="cinema-project-link"','attachSplitFilm','socialParts('])assert(cinema.includes(tag),`Cinema lost ${tag}`)
assert(foh.includes('screens.crops.forEach'),'FOH cropped monitor update optimization absent')
assert(foh.includes('512, 420') && foh.includes('1 / 18'),'FOH screen source res/update throttle changed')
assert(beac.includes('<SocialDrops'),'Beacon lost social links interaction')
assert(player.includes("best === 'station' ? 'about' : best"),'New station E navigation fallback missing')
assert(!station.includes('PANELS.about.stats'),'Central Station must not republish prototype statistics')
for(const f of ['App.tsx','reality/RealityHost.tsx','stage/ShowSystem.tsx','stage/shows.ts','ui/Overlay.tsx','scene/Experience.tsx'])exists(f)
let files=0,imports=0,errors=[]
function walk(dir){for(const o of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,o.name);if(o.isDirectory())walk(f);else if(/\.(tsx|ts)$/.test(f)){files++
 const content=fs.readFileSync(f,'utf8'),sf=ts.createSourceFile(f,content,ts.ScriptTarget.Latest,true,f.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS)
 for(const d of sf.parseDiagnostics)errors.push(`${f}: ${ts.flattenDiagnosticMessageText(d.messageText,' ')}`)
 for(const m of content.matchAll(/from\s+['"](\.{1,2}\/[^'"]+)['"]/g)){imports++; const full=path.resolve(path.dirname(f),m[1]);if(!['.ts','.tsx','.js','.jsx','','/index.ts','/index.tsx'].some(x=>fs.existsSync(full+x)))errors.push(`Missing import ${m[1]} in ${f}`)}
}}}
walk(path.join(src,'src'))
assert.equal(errors.length,0,errors.slice(0,20).join('\n'))
console.log(JSON.stringify({status:'STATIC_PASS',filesParsed:files,relativeImports:imports,source:src,liveRuntime:'NOT_TESTED',bundle:'NOT_BUILT'},null,2))

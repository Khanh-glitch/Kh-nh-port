# RUNNING ORDER — OFFICIAL DESIGN AUDITION PROMPT
## Portfolio Hero / Interaction Test — NOT the final website

You are an expert creative front-end designer-engineer. Build a **single self-contained `index.html`** that functions as an official visual audition for one portfolio concept.

This is **not** a production portfolio. Do not add About, Contact, full case studies, a loader, a custom cursor, a CMS, a game, or decorative features. The only purpose of this build is to determine whether the core visual mechanism is strong enough to become the portfolio's final direction.

Use the real media files in `./assets/` exactly as described below.

---

# 1. THE IDEA

Working internal name: **RUNNING ORDER / CONTINUOUS CUE TRACK**

The portfolio is one continuous sequence of real work moving through a fixed cue point.

The user scrolls or drags the sequence.

When a project reaches the cue point, that project **expands out of the same continuous track** and becomes the dominant hero composition. When the user continues, it **compresses back into that same track**, the sequence advances, and the next project expands.

The key memory sentence is:

> "The portfolio where all the work runs through one continuous track and each project opens when it reaches the cue."

The website must feel like an editorial / spatial instrument, **not** a concert website, DAW, cassette, film reel, Spotify interface, stage-control system, or carousel template.

Music and event-production logic should exist in the behavior — sequence, cue, timing, transition — not in literal music equipment.

---

# 2. WHAT THIS TEST MUST PROVE

The test passes only if all of the following are true:

1. **Work is visible immediately.**
   On first paint, a real project image is already the strongest visual element.

2. **One continuous object is legible.**
   The work sequence must read as one continuous media track, not a row of separate cards.

3. **The active project comes from the track itself.**
   Do not fade in a second independent hero image above the track. The same segment that exists in the track must visibly become the large active project.

4. **The transition is reversible.**
   Scroll backward and the geometry physically reverses. No trigger-and-wait animation.

5. **A paused mid-transition still looks designed.**
   At 30%, 50%, and 70%, the frame must not look like random rectangles floating around.

6. **Three radically different assets still belong to the same system.**
   The mechanism must survive documentary photography, moving social content, and a tall music/editorial image.

7. **Technical architecture is simpler than the visual impression.**
   No Three.js, WebGL, shader, physics, particles, or simulation.

8. **It must not look like a generic horizontal carousel.**

---

# 3. REAL ASSETS

Use these local files:

### Project 01 — Prompt to Play / AI Contest
`./assets/01_ai_prompt_to_play.jpg`

Content character:
- documentary team/work photograph
- landscape
- natural event lighting
- visually busy, real-world image

Temporary display metadata:
- `01`
- `PROMPT TO PLAY`
- `AI / COMPETITION`
- `2026`

### Project 02 — Social Experiment / Social Media
Video:
`./assets/02_social_debate.mp4`

Poster fallback:
`./assets/02_social_debate_poster.jpg`

Content character:
- real field footage
- bold on-video graphic typography
- landscape 16:9
- red / black / green visual changes

Temporary display metadata:
- `02`
- `SOCIAL EXPERIMENT`
- `CONTENT / VIDEO`
- `2026`

The video should be muted, looped, `playsinline`, and only actively play when Project 02 is near or at its resolved active state. Use the poster when inactive or if autoplay fails.

### Project 03 — Music
Full vertical artwork:
`./assets/03_music_vibes.jpg`

Optional supporting crop:
`./assets/03_music_performance.jpg`

Content character:
- tall portrait editorial board
- bright magenta / blue / yellow accents
- music, composer/singer/performance material

Temporary display metadata:
- `03`
- `MUSIC LED MY LIFE`
- `MUSIC / PERFORMANCE`
- `2026`

The full portrait artwork must remain recognizable. Do not force it into a generic 16:9 crop.

---

# 4. ART DIRECTION

The interface itself should be quiet enough that the work owns the color.

Target feeling:

**contemporary editorial system × physical sequencing instrument × restrained kinetic typography**

Use:
- warm near-white / paper-like background OR extremely light neutral grey
- near-black typography
- hairline structural marks
- one neutral cue marker
- real media as the main source of color
- crisp typography
- strong negative space
- mostly flat front-facing composition with a small amount of depth only where it helps show continuity

Do not use:
- neon
- glow
- gradients as decoration
- particles
- fog
- glassmorphism
- chrome
- speaker / microphone / waveform icons
- timeline UI copied from editing software
- film perforations
- cassette / vinyl visual language
- stage truss
- LED-wall aesthetics
- rounded cards
- drop shadows on project tiles
- floating cards
- blob masks
- generic Awwwards serif-over-black styling
- a custom cursor

**Work owns color. Interface owns rhythm and space.**

---

# 5. TYPOGRAPHY

Keep typography deliberately neutral but sharp because typography is not what this test is selecting.

Use:
- `Inter Tight` or `Archivo` for display / project titles
- `IBM Plex Mono` or `DM Mono` for metadata

Load from Google Fonts.

Project titles should be large enough to read instantly but never overpower the active media.

No decorative serif headline in this test.

---

# 6. GLOBAL EXPERIENCE MODEL

The page is one fixed `100dvh` design surface.

The browser may have a hidden vertical scroll range underneath so the wheel can generate progress, but the visible composition itself stays fixed in the viewport.

There are exactly three project stops.

Use one master variable conceptually equivalent to:

```js
cueProgress
```

It moves continuously through the full sequence.

All project geometry must derive from that same progress.

Do not create independent timelines that can drift out of sync.

Also support pointer drag on empty space or on the track:
- horizontal drag maps directly to the same progress
- dragging left/right must feel physically connected to the track
- no tutorial required because wheel/trackpad already works

Native cursor only.

---

# 7. THE CONTINUOUS TRACK — HARD INVARIANTS

The sequence must visually behave as **one continuous media surface**.

Hard rules:

- no visible gaps between project segments in the compressed track
- no card borders
- no rounded corners on individual track segments
- no independent box shadows
- no "three thumbnails in a row" look
- adjacent projects must share the same baseline / material body
- the active project is still visibly connected to the body of the track
- the project must expand from its location at the cue, not teleport to a separate hero container

A viewer should be able to understand this visual sentence without explanation:

> "This large project came out of that strip, and it will return into it."

---

# 8. CUE POINT

There is one fixed cue marker.

It can be:
- one vertical hairline,
- a thin bracket,
- or a restrained two-line gate.

It must not look like:
- an audio playhead copied from a DAW
- a video editor timeline cursor
- a stage lighting control

The cue marker is structural, almost architectural.

It remains fixed while the track moves through it.

---

# 9. BUILD THREE DESIGN VARIANTS IN THE SAME FILE

This is a design audition.

Create three distinct **geometry treatments of the same concept**, selectable using small top-right controls `A / B / C` and keyboard keys `1 / 2 / 3`.

The controls are utility-only and visually quiet.

Do not change the core interaction between variants.

## VARIANT A — CENTER GATE

Goal:
Test the clearest possible interpretation.

- cue point near the visual center
- continuous track runs horizontally through the viewport
- active project expands around the center cue
- expansion should feel like the band itself gains height and presence around the cue
- title/meta remains anchored outside or beside the enlarged media
- composition should feel balanced but not like a centered slideshow

Risk to avoid:
generic Cover Flow / centered carousel.

## VARIANT B — OFFSET EDITORIAL GATE

Goal:
Test a stronger asymmetric art direction.

- cue point is clearly off-center, roughly in the left-middle region
- project identity / number / title occupies the smaller side
- active media expands primarily into the larger opposite field
- the continuous track should remain visible before and after the cue
- this should feel closest to a high-end editorial portfolio, while still preserving the physical cue mechanism

Risk to avoid:
ordinary left-text / right-image agency layout.

## VARIANT C — LOW TRACK / VERTICAL RELEASE

Goal:
Test whether the sequence can become a more iconic object without extra technical complexity.

- the compressed continuous track lives lower in the viewport
- when a project reaches the cue, its segment expands upward out of that same track
- the base track remains visibly continuous beneath or through the active project
- the active project should feel "released" from the sequence, not placed above a thumbnail rail

Risk to avoid:
standard thumbnail strip + hero image gallery.

---

# 10. GEOMETRY — USE RELATIONSHIPS, NOT FAKE PRECISION

Do not treat the following as exact production values.

They are audition ranges.

At a desktop reference around 1440×900:

Resolved active media should typically occupy approximately:
- `55–72%` of viewport width
- `52–72%` of viewport height

The compressed track should remain visually meaningful, not microscopic:
- roughly `10–22%` of viewport height depending on variant

Project title block:
- clearly secondary to media
- enough breathing room to read in under one second

Cue marker:
- visually thin
- high enough contrast to locate
- never visually louder than the project

Use judgment inside these ranges.

The purpose of this build is to discover the geometry worth freezing later.

---

# 11. TRANSITION BEHAVIOR

The transition is the main test.

For A → B:

### At resolved A
- A is dominant
- B and C exist only as continuation of the same compressed track
- real work is immediately readable

### Leaving A
- A must compress back toward the track
- its transform origin / clipping logic should make the relationship physically obvious
- title/meta may reduce or reposition, but should not randomly fade first

### Mid-transition
- A and B must both be visible as regions of one continuous sequence
- there must still be one coherent silhouette
- avoid separated floating planes
- avoid stacking cards in perspective
- avoid an empty dead frame

### Entering B
- when B reaches the cue, the B segment expands directly from the track
- the video can begin playing as B becomes dominant

### Resolved B
- B is now the large work surface
- track continuity remains legible

Repeat for B → C.

No crossfade-only transitions.

Opacity can support geometry, but geometry must carry the transition.

---

# 12. INTERACTION FEEL

Wheel / trackpad:
- maps continuously to sequence progress
- use modest smoothing only to remove input noise
- never make the user wait for a timeline to finish

Drag:
- direct 1:1-feeling mapping
- release may have a very small inertial settle or snap only when close to a project stop
- do not create heavy physics

The project stops may have a restrained magnetic settling behavior, but the user must always be able to reverse immediately.

No overshoot circus.
No elastic bounce.

---

# 13. HEADER / UTILITY UI

Keep only:

Top-left:
`KHANH`
small descriptor such as:
`SELECTED WORK / 2026`

Top-right:
- `A B C` variant switch
- very small `SCROLL / DRAG`

Optional bottom:
- `01 / 03` project counter

Do not add a full navigation bar.

This is a mechanism test.

---

# 14. TECHNICAL CONSTRAINTS

Deliver one `index.html`.

Allowed:
- HTML
- CSS
- vanilla JS
- GSAP from CDN only if it meaningfully simplifies progress interpolation

Prefer DOM/CSS transforms and clip-path.

Do not use:
- React
- Next.js
- Three.js
- WebGL
- canvas rendering
- shader code
- physics libraries
- Lenis unless genuinely necessary

The visible result should feel more complex than the code architecture.

Use CSS custom properties for:
- progress
- active state
- track position
- cue position
- project expansion amount

Avoid per-frame layout thrashing.
Prefer transform / clip / scale / opacity.

---

# 15. VIDEO RULES

Project 02:
- `muted`
- `loop`
- `playsinline`
- use poster when not active
- pause when far from active state
- do not let video decoding damage interaction smoothness

If playback fails, the poster must preserve the design completely.

---

# 16. ACCESSIBILITY / INPUT SAFETY FOR THIS TEST

Even though this is not production:

- wheel interaction must not trap keyboard users
- provide left/right arrow key navigation between project stops
- variant controls must be real buttons
- respect `prefers-reduced-motion` by replacing continuous spatial interpolation with short simple state changes
- preserve all visible text
- no essential information available only on hover

Do not spend time on full production accessibility beyond this.

---

# 17. HARD FAILURE CONDITIONS

The design test is a FAILURE if any variant does any of the following:

1. Reads immediately as a carousel.
2. Reads as a film strip, cassette, DAW, timeline editor, or stage-control UI.
3. Uses floating independent rectangles to create "depth."
4. Makes the cue marker more memorable than the work.
5. Shrinks the project work to make room for the mechanism.
6. Requires explanatory copy to understand the interaction.
7. Treats the tall music artwork as an awkward crop.
8. Only looks good with one of the three projects.
9. Uses decorative effects to disguise a weak composition.
10. Requires Three.js/WebGL to become convincing.
11. Produces a mid-transition frame that looks accidental.
12. Becomes a normal thumbnail rail plus separate hero image.

If the underlying concept cannot avoid those failures with simple DOM/CSS geometry, do not rescue it with more technology.

---

# 18. WHAT TO OPTIMIZE FOR

In priority order:

1. **Real work is immediately dominant**
2. **Continuous-object illusion**
3. **Memorable expansion/compression behavior**
4. **Excellent composition at resolved states**
5. **Excellent composition at 50% transition**
6. **Direct tactile interaction**
7. **Low implementation complexity**
8. **Typography**
9. **Decorative polish**

There should be almost no decoration.

---

# 19. DELIVERABLE BEHAVIOR

On load:
- open Variant B by default because the asymmetric option is the strongest stress test for editorial usability
- start at Project 01 resolved
- actual work is already visible

User can:
- scroll through 01 → 02 → 03
- scroll backward
- drag the continuous track
- press arrows to move project-to-project
- press `1`, `2`, `3` to compare geometry variants

Preserve progress when switching variants if practical; otherwise reset cleanly to the nearest project.

---

# 20. FINAL SELF-CHECK BEFORE YOU FINISH

Before presenting the result, inspect all three variants at:

- Project 01 resolved
- Project 01 → 02 at ~50%
- Project 02 resolved
- Project 02 → 03 at ~50%
- Project 03 resolved

Ask:

### Continuity
Does the large project visibly belong to the same object as the track?

### Work-first
Would a recruiter understand there is real work within one second?

### Memorability
Is there a visual behavior more specific than "horizontal scrolling portfolio"?

### Asset stress
Do landscape photography, video, and portrait music artwork all work?

### Complexity
Could this plausibly be maintained as DOM/CSS/JS rather than a graphics-engine project?

If a variant fails, keep it visible for comparison but do not decorate it to hide the failure.

Do not declare a winner in the UI. The human reviewer will select the direction.

---

# 21. IMPORTANT

This build is an **audition**, not a final portfolio.

Do not add more features because the page feels sparse.

Sparse is correct.

The test succeeds only if the core idea is compelling **without**:
- particles
- sound
- a loader
- WebGL
- custom cursor
- special effects
- an elaborate navigation system

If the core mechanism is strong, those things are unnecessary.

Build the mechanism beautifully.

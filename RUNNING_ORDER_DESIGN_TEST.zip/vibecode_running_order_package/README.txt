RUNNING ORDER — Official Design Test Package

Give the prompt and the entire assets folder to the coding/design AI together.

Contents:
- RUNNING_ORDER_DESIGN_TEST_PROMPT.md
- assets/01_ai_prompt_to_play.jpg
- assets/02_social_debate.mp4
- assets/02_social_debate_poster.jpg
- assets/03_music_vibes.jpg
- assets/03_music_performance.jpg

Purpose:
This is a bounded design audition for the Continuous Cue Track / Running Order portfolio concept.
It is deliberately not a production portfolio.

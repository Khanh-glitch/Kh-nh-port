import{t as e}from"./rolldown-runtime.Bi-D_2cA.mjs";import{I as t,R as n,_ as r,b as i,l as a,o,s,w as c,y as l}from"./react.Dxe_2v0O.mjs";import{g as u,j as d,ot as f,r as p,y as m}from"./framer.fqDUkQf6.mjs";function h(e){let t=document.createElement(`canvas`).getContext(`2d`);t.fillStyle=`#000`,t.fillStyle=e;let n=t.fillStyle;if(n.startsWith(`#`)){let e=parseInt(n.slice(1),16);return[(e>>16&255)/255,(e>>8&255)/255,(e&255)/255]}let r=n.match(/[\d.]+/g)||[`0`,`0`,`0`];return[r[0]/255,r[1]/255,r[2]/255]}function g(e,t,n,r){let i=1/Math.tan(e/2),a=1/(n-r);return new Float32Array([i/t,0,0,0,0,i,0,0,0,0,(r+n)*a,-1,0,0,2*r*n*a,0])}function _(e,t,n){let r=e[0]-t[0],i=e[1]-t[1],a=e[2]-t[2],o=Math.hypot(r,i,a);r/=o,i/=o,a/=o;let s=n[1]*a-n[2]*i,c=n[2]*r-n[0]*a,l=n[0]*i-n[1]*r;o=Math.hypot(s,c,l),s/=o,c/=o,l/=o;let u=i*l-a*c,d=a*s-r*l,f=r*c-i*s;return new Float32Array([s,u,r,0,c,d,i,0,l,f,a,0,-(s*e[0]+c*e[1]+l*e[2]),-(u*e[0]+d*e[1]+f*e[2]),-(r*e[0]+i*e[1]+a*e[2]),1])}function v(){let e=[[[0,1,0],[[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]]],[[0,-1,0],[[-1,-1,-1],[1,-1,-1],[1,-1,1],[-1,-1,1]]],[[1,0,0],[[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]]],[[-1,0,0],[[-1,-1,-1],[-1,-1,1],[-1,1,1],[-1,1,-1]]],[[0,0,1],[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]]],[[0,0,-1],[[-1,-1,-1],[-1,1,-1],[1,1,-1],[1,-1,-1]]]],t=[];for(let[n,r]of e)for(let e of[0,1,2,0,2,3]){let i=r[e];t.push(i[0]*.5,i[1]*.5-.5,i[2]*.5,n[0],n[1],n[2])}return new Float32Array(t)}function y(e){let t=i(null),s=i(e);s.current=e;let c=i(!0),u=f.current()===f.canvas,[d,p]=r(!1);if(l(()=>{let e=t.current;if(!e)return;let r=e.getContext(`webgl2`,{antialias:!0,alpha:!1,powerPreference:`high-performance`});if(!r){p(!0);return}e.addEventListener(`webglcontextlost`,()=>p(!0));let i=(e,t)=>{let n=r.createShader(e);return r.shaderSource(n,t),r.compileShader(n),r.getShaderParameter(n,r.COMPILE_STATUS)||console.warn(r.getShaderInfoLog(n)),n},a=r.createProgram();r.attachShader(a,i(r.VERTEX_SHADER,b)),r.attachShader(a,i(r.FRAGMENT_SHADER,x)),r.linkProgram(a),r.useProgram(a);let o=e=>r.getUniformLocation(a,e),l={proj:o(`uProj`),view:o(`uView`),time:o(`uTime`),grid:o(`uGrid`),gap:o(`uGap`),height:o(`uHeight`),scale:o(`uScale`),speed:o(`uSpeed`),pointer:o(`uPointer`),pointerAmt:o(`uPointerAmt`),bg:o(`uBg`),block:o(`uBlock`),accent:o(`uAccent`),cam:o(`uCam`),glow:o(`uGlow`),fog:o(`uFog`),res:o(`uRes`),fadeTop:o(`uFadeTop`),fadeBottom:o(`uFadeBottom`),vignette:o(`uVignette`)},d=r.createVertexArray();r.bindVertexArray(d);let f=r.createBuffer();r.bindBuffer(r.ARRAY_BUFFER,f),r.bufferData(r.ARRAY_BUFFER,v(),r.STATIC_DRAW),r.enableVertexAttribArray(0),r.vertexAttribPointer(0,3,r.FLOAT,!1,24,0),r.enableVertexAttribArray(1),r.vertexAttribPointer(1,3,r.FLOAT,!1,24,12);let m=r.createBuffer(),y=0,S=-1,C=e=>{let t=new Float32Array(e*e*2),n=0;for(let r=0;r<e;r++)for(let i=0;i<e;i++)t[n++]=i-e/2,t[n++]=r-e/2;r.bindBuffer(r.ARRAY_BUFFER,m),r.bufferData(r.ARRAY_BUFFER,t,r.STATIC_DRAW),r.enableVertexAttribArray(2),r.vertexAttribPointer(2,2,r.FLOAT,!1,8,0),r.vertexAttribDivisor(2,1),y=e*e,S=e};r.enable(r.DEPTH_TEST),r.enable(r.CULL_FACE);let w={x:0,y:0,tx:0,ty:0,amt:0,tamt:0},T=t=>{let n=e.getBoundingClientRect();t.clientY<n.top||t.clientY>n.bottom?w.tamt=0:(w.tx=(t.clientX-n.left)/n.width*2-1,w.ty=(t.clientY-n.top)/n.height*2-1,w.tamt=1)},E=()=>{w.tamt=0};n.addEventListener(`pointermove`,T),document.addEventListener(`pointerleave`,E);let D=n.matchMedia?.(`(prefers-reduced-motion: reduce)`).matches,O=0,k=!0,A=new IntersectionObserver(([e])=>{k=e.isIntersecting});A.observe(e);let j=performance.now(),M=()=>{let t=s.current,i=Math.min(n.devicePixelRatio||1,2),a=Math.max(1,Math.round(e.clientWidth*i)),o=Math.max(1,Math.round(e.clientHeight*i));(e.width!==a||e.height!==o)&&(e.width=a,e.height=o);let c=Math.round(t.gridSize);c!==S&&C(c);let f=u||D?8:(performance.now()-j)/1e3,p=.06;w.x+=(w.tx-w.x)*p,w.y+=(w.ty-w.y)*p,w.amt+=((t.interactive?w.tamt:0)-w.amt)*.04;let m=h(t.background);r.viewport(0,0,a,o),r.clearColor(m[0],m[1],m[2],1),r.clear(r.COLOR_BUFFER_BIT|r.DEPTH_BUFFER_BIT);let v=a/o,b=t.parallax*+!!t.interactive,x=c*.42,T=[w.x*b*4,t.cameraHeight+-w.y*b*2,x],E=[0,0,-c*.12+t.tilt];r.uniformMatrix4fv(l.proj,!1,g(40*Math.PI/180,v,.1,400)),r.uniformMatrix4fv(l.view,!1,_(T,E,[0,1,0])),r.uniform3fv(l.cam,T),r.uniform1f(l.time,f),r.uniform1f(l.grid,c),r.uniform1f(l.gap,t.blockGap),r.uniform1f(l.height,t.amplitude),r.uniform1f(l.scale,t.waveScale),r.uniform1f(l.speed,t.speed),r.uniform1f(l.glow,t.glow),r.uniform1f(l.fog,t.fog),r.uniform2f(l.res,a,o),r.uniform1f(l.fadeTop,t.fadeTop),r.uniform1f(l.fadeBottom,t.fadeBottom),r.uniform1f(l.vignette,t.vignette),r.uniform2f(l.pointer,w.x*c*.35,c*.05+w.y*c*.2),r.uniform1f(l.pointerAmt,w.amt),r.uniform3fv(l.bg,m),r.uniform3fv(l.block,h(t.block)),r.uniform3fv(l.accent,h(t.accent)),r.bindVertexArray(d),r.drawArraysInstanced(r.TRIANGLES,0,36,y)},N=u||D,P=()=>{k&&(!N||c.current)&&(c.current=!1,M()),O=requestAnimationFrame(P)};return P(),()=>{cancelAnimationFrame(O),A.disconnect(),n.removeEventListener(`pointermove`,T),document.removeEventListener(`pointerleave`,E),r.getExtension(`WEBGL_lose_context`)?.loseContext()}},[u]),l(()=>{c.current=!0}),d){let t=`color-mix(in srgb, ${e.accent} 34%, transparent)`;return/*#__PURE__*/ a(`div`,{"aria-hidden":`true`,style:{...e.style,width:`100%`,height:`100%`,position:`relative`,overflow:`hidden`,background:e.background},children:[/*#__PURE__*/ o(`div`,{style:{position:`absolute`,left:`-60%`,right:`-60%`,top:`38%`,height:`120%`,transformOrigin:`50% 0`,transform:`perspective(760px) rotateX(62deg)`,background:`repeating-linear-gradient(90deg, #000 0 3px, transparent 3px 84px), repeating-linear-gradient(0deg, #000 0 3px, transparent 3px 84px), ${e.block}`}}),/*#__PURE__*/ o(`div`,{style:{position:`absolute`,inset:0,background:`radial-gradient(46% 22% at 62% 62%, ${t}, transparent 72%), linear-gradient(180deg, ${e.background} 36%, transparent 58%)`}})]})}return/*#__PURE__*/ o(`canvas`,{ref:t,style:{...e.style,width:`100%`,height:`100%`,display:`block`,background:e.background}})}var b,x;function S(){return(S=e((()=>{t(),s(),c(),d(),b=`#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aCell;
uniform mat4 uProj, uView;
uniform float uTime, uGrid, uGap, uHeight, uScale, uSpeed;
uniform vec2 uPointer; uniform float uPointerAmt;
out vec3 vNormal; out vec3 vLocal; out vec3 vWorld; out float vLift; out float vGlowMask;

vec3 hash3(vec2 p){ vec3 q=vec3(dot(p,vec2(127.1,311.7)),dot(p,vec2(269.5,183.3)),dot(p,vec2(419.2,371.9))); return fract(sin(q)*43758.5453); }
float noise(vec2 p){
  vec2 i=floor(p), f=fract(p); vec2 u=f*f*(3.0-2.0*f);
  float a=hash3(i).x, b=hash3(i+vec2(1,0)).x, c=hash3(i+vec2(0,1)).x, d=hash3(i+vec2(1,1)).x;
  return mix(mix(a,b,u.x),mix(c,d,u.x),u.y);
}
float fbm(vec2 p){ float s=0.0,a=0.5; for(int i=0;i<4;i++){ s+=a*noise(p); p*=2.03; a*=0.5; } return s; }

void main(){
  vec2 cell=aCell;
  float t=uTime*uSpeed;
  vec2 p=cell*uScale;
  float h=fbm(p+vec2(t*0.35,t*0.22));
  h=h*h*1.6;
  // slow rolling swell
  h+=0.35*sin(cell.x*0.18+t*0.9)*cos(cell.y*0.14-t*0.6);
  // pointer ripple
  float d=distance(cell,uPointer);
  float ripple=exp(-d*d*0.012)*uPointerAmt;
  h+=ripple*1.4;
  // quantize a little for a stepped, voxel feel
  h=floor(h*6.0+0.5)/6.0;
  float lift=h*uHeight;
  float s=1.0-uGap;
  vec3 local=aPos;
  vec3 world=vec3(cell.x, lift, cell.y)+local*vec3(s,1.0,s);
  vNormal=aNormal; vLocal=aPos; vWorld=world; vLift=h;
  vGlowMask=hash3(cell).y;
  gl_Position=uProj*uView*vec4(world,1.0);
}`,x=`#version 300 es
precision highp float;
in vec3 vNormal; in vec3 vLocal; in vec3 vWorld; in float vLift; in float vGlowMask;
uniform vec3 uBg, uBlock, uAccent, uCam;
uniform float uTime, uGlow, uFog, uSpeed, uFadeTop, uFadeBottom, uVignette;
uniform vec2 uRes;
out vec4 outColor;
void main(){
  vec3 n=normalize(vNormal);
  vec3 L=normalize(vec3(-0.45,0.85,0.35));
  float diff=max(dot(n,L),0.0);
  float top=step(0.5,n.y);
  // bevelled edges: darken near the face borders
  vec2 fc = abs(n.y)>0.5 ? vLocal.xz : (abs(n.x)>0.5 ? vLocal.zy : vLocal.xy);
  float edge=smoothstep(0.40,0.5,max(abs(fc.x),abs(fc.y)));
  vec3 base=uBlock*(0.28+0.85*diff)+uBlock*0.18*top;
  base*=1.0-edge*0.55;
  // accent: a travelling band + sparse lit tiles on the highest blocks
  float band=smoothstep(0.965,1.0,sin(vWorld.x*0.08+vWorld.z*0.05-uTime*uSpeed*1.4)*0.5+0.5);
  float hot=smoothstep(0.85,1.25,vLift)*step(0.93,vGlowMask);
  float g=(band*0.45+hot*0.9)*top*uGlow;
  vec3 col=mix(base,uAccent*(1.1+0.4*diff),clamp(g,0.0,1.0));
  // rim
  vec3 V=normalize(uCam-vWorld);
  float rim=pow(1.0-max(dot(n,V),0.0),3.0);
  col+=uAccent*rim*0.08*uGlow;
  // depth fog
  float dist=length(uCam-vWorld);
  float f=1.0-exp(-pow(dist*uFog*0.012,1.6));
  col=mix(col,uBg,clamp(f,0.0,1.0));
  // screen-space fades so content on top stays legible
  vec2 uv=gl_FragCoord.xy/uRes;
  col=mix(col,uBg,(1.0-smoothstep(0.0,uFadeBottom,uv.y))*0.92);
  col=mix(col,uBg,smoothstep(1.0-uFadeTop,1.0,uv.y)*0.9);
  float vig=smoothstep(0.35,1.05,length((uv-0.5)*vec2(1.25,1.0)));
  col=mix(col,uBg,vig*uVignette);
  outColor=vec4(col,1.0);
}`,y.defaultProps={background:`#07080A`,block:`#2C2E34`,accent:`#FF5A1F`,gridSize:64,blockGap:.08,amplitude:3.2,waveScale:.07,speed:.35,glow:.85,fog:1.5,fadeTop:.3,fadeBottom:.35,vignette:.55,cameraHeight:9,tilt:0,interactive:!0,parallax:.6},u(y,{background:{type:p.Color,title:`Background`},block:{type:p.Color,title:`Blocks`},accent:{type:p.Color,title:`Accent`},gridSize:{type:p.Number,title:`Grid`,min:16,max:120,step:2},blockGap:{type:p.Number,title:`Gap`,min:0,max:.5,step:.01},amplitude:{type:p.Number,title:`Height`,min:0,max:10,step:.1},waveScale:{type:p.Number,title:`Wave Size`,min:.01,max:.3,step:.005},speed:{type:p.Number,title:`Speed`,min:0,max:2,step:.05},glow:{type:p.Number,title:`Glow`,min:0,max:2,step:.05},fog:{type:p.Number,title:`Fog`,min:0,max:4,step:.05},fadeTop:{type:p.Number,title:`Fade Top`,min:0,max:1,step:.01},fadeBottom:{type:p.Number,title:`Fade Bottom`,min:0,max:1,step:.01},vignette:{type:p.Number,title:`Vignette`,min:0,max:1,step:.01},cameraHeight:{type:p.Number,title:`Camera Y`,min:2,max:30,step:.5},tilt:{type:p.Number,title:`Look Offset`,min:-30,max:30,step:.5},interactive:{type:p.Boolean,title:`Pointer`},parallax:{type:p.Number,title:`Parallax`,min:0,max:2,step:.05,hidden:e=>!e.interactive}})})))()}var C,w,T;function E(){return(E=e((()=>{d(),m.loadFonts([`GF;Inter Tight-500`,`GF;Inter Tight-700`,`GF;Inter Tight-700italic`,`GF;Inter Tight-500italic`]),C=[{explicitInter:!0,fonts:[{cssFamilyName:`Inter Tight`,openType:!0,source:`google`,style:`normal`,uiFamilyName:`Inter Tight`,url:`https://fonts.gstatic.com/s/intertight/v9/NGSnv5HMAFg6IuGlBNMjxJEL2VmU3NS7Z2mjPQ-qWSRToK8EPg.woff2`,weight:`500`},{cssFamilyName:`Inter Tight`,openType:!0,source:`google`,style:`normal`,uiFamilyName:`Inter Tight`,url:`https://fonts.gstatic.com/s/intertight/v9/NGSnv5HMAFg6IuGlBNMjxJEL2VmU3NS7Z2mj6AiqWSRToK8EPg.woff2`,weight:`700`},{cssFamilyName:`Inter Tight`,openType:!0,source:`google`,style:`italic`,uiFamilyName:`Inter Tight`,url:`https://fonts.gstatic.com/s/intertight/v9/NGShv5HMAFg6IuGlBNMjxLsC66ZMtb8hyW62x0ylGC5SgqoUPvi5.woff2`,weight:`700`},{cssFamilyName:`Inter Tight`,openType:!0,source:`google`,style:`italic`,uiFamilyName:`Inter Tight`,url:`https://fonts.gstatic.com/s/intertight/v9/NGShv5HMAFg6IuGlBNMjxLsC66ZMtb8hyW62x0xwHy5SgqoUPvi5.woff2`,weight:`500`}]}],w=[`.framer-AHpvO .framer-styles-preset-coeo2:not(.rich-text-wrapper), .framer-AHpvO .framer-styles-preset-coeo2.rich-text-wrapper p { --framer-font-family: "Inter Tight", "Inter Tight Placeholder", sans-serif; --framer-font-family-bold: "Inter Tight", "Inter Tight Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Tight", "Inter Tight Placeholder", sans-serif; --framer-font-family-italic: "Inter Tight", "Inter Tight Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 15px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: -0.01em; --framer-line-height: 1em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-2496fc96-9b99-48fe-96af-2e817aba82a7, #07080a); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`],T=`framer-AHpvO`})))()}export{y as a,E as i,w as n,S as o,C as r,T as t};
//# sourceMappingURL=tP2g4iyGy.LXE_q7js.mjs.map